import express, { type Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { csrfGuard } from "./middlewares/csrf";
import { logger } from "./lib/logger";

const app: Express = express();

// Behind the Replit reverse proxy (a single trusted hop): honor
// X-Forwarded-Proto/Host so OAuth redirect URIs and secure cookies resolve to
// the real https app domain. A specific hop count (not `true`) keeps req.ip
// trustworthy so the AI-endpoint IP rate limit can't be bypassed by a spoofed
// X-Forwarded-For (express-rate-limit ERR_ERL_PERMISSIVE_TRUST_PROXY).
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(cookieParser());
// Block cross-site state changes on cookie-authenticated routes. Runs after
// cookie-parser (needs req.cookies) and before the routers.
app.use(csrfGuard);
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use("/api", router);

export default app;
